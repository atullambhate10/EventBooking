package com.Login;

public class AddEvent {
private String EventName,EventON,EventHCN,EmailOrg,Eventcode,NumberOfSeats,EventCPS,EventAddress,EventDate;

public String getEventName() {
	return EventName;
}

public void setEventName(String eventName) {
	this.EventName = eventName;
}

public String getEventON() {
	return EventON;
}

public void setEventON(String eventON) {
	this.EventON = eventON;
}

public String getEventHCN() {
	return EventHCN;
}

public void setEventHCN(String eventHCN) {
	this.EventHCN = eventHCN;
}

public String getEmailOrg() {
	return EmailOrg;
}

public void setEmailOrg(String emailOrg) {
	this.EmailOrg = emailOrg;
}

public String getEventcode() {
	return Eventcode;
}

public void setEventcode(String eventcode) {
	this.Eventcode = eventcode;
}

public String getNumberOfSeats() {
	return NumberOfSeats;
}

public void setNumberOfSeats(String numberOfSeats) {
	this.NumberOfSeats = numberOfSeats;
}

public String getEventCPS() {
	return EventCPS;
}

public void setEventCPS(String eventCPS) {
	this.EventCPS = eventCPS;
}

public String getEventAddress() {
	return EventAddress;
}

public void setEventAddress(String eventAddress) {
	this.EventAddress = eventAddress;
}

public String getEventDate() {
	return EventDate;
}

public void setEventDate(String eventDate) {
	this.EventDate = eventDate;
}



}